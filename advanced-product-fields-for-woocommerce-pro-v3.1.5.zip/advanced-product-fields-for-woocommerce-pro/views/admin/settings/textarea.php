<?php /* @var $model array */ ?>

<textarea rv-on-keyup="onChange" rv-value="<?php echo $model['is_field_setting'] ? 'field' : 'settings'; ?>.<?php echo $model['id']; ?>" rows="5"></textarea>