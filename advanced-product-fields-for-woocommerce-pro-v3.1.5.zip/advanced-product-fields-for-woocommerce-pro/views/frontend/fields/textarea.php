<?php
/** @var array $model */
?>
<textarea <?php echo $model['field_attributes']; ?>><?php echo $model['default'][0]; ?></textarea>