<?php
/** @var array $model */
?>

<input type="url" value="<?php echo $model['default'][0]; ?>" <?php echo $model['field_attributes']; ?> />
