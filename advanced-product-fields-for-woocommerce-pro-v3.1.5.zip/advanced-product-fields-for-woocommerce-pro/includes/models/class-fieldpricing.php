<?php
namespace SW_WAPF_PRO\Includes\Models {

        class FieldPricing
    {
        public $enabled = false;

        public $amount = 0;

                public $type = 'fixed';

            }

}
