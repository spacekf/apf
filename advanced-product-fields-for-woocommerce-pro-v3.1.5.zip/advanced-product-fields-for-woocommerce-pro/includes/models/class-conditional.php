<?php

namespace SW_WAPF_PRO\Includes\Models {

    class Conditional
    {
        public $rules = [];

            }
}