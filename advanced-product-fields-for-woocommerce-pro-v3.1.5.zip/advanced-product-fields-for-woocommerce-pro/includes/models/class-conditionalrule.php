<?php

namespace SW_WAPF_PRO\Includes\Models {

    class ConditionalRule
    {

        public $field;

        public $condition;

        public $value;

        public $generated = false;

    }
}